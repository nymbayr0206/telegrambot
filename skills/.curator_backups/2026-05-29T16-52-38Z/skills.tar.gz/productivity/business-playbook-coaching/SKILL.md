---
name: business-playbook-coaching
description: Turn business/sales playbooks, PDFs, and founder frameworks into reusable coaching knowledge bases, sales processes, daily action plans, and weekly event systems.
platforms: [linux, macos, windows]
---

# Business Playbook Coaching

## When to use

Use this skill when the user:

- Shares a business/sales/leadership PDF, book, playbook, SOP, or training manual and asks you to “read it” or become their coach based on it.
- Wants a business, sales, recruiting, prospecting, or leadership system extracted from a document.
- Asks for daily/weekly action plans, accountability scoreboards, sales process, fast-start plan, closing questions, or event/showcase strategy based on a playbook.
- Wants the material adapted into a modern business such as AI agents, automation services, consulting, lead generation, CRM, Odoo, Google Sheets, or newsletter funnels.

## Core principle

Do not merely summarize the document. Convert it into an operating system:

1. Knowledge base
2. Pipeline model
3. Sales process
4. Daily action plan
5. Weekly review/event rhythm
6. Fast-start/onboarding plan
7. Leadership/duplication system
8. Scripts, questions, and scoreboards

## Workflow

### 1. Extract and preserve the source

- If the source is a PDF, extract text using available document tools or Python libraries.
- Save the extracted text next to the document or under a stable knowledge-base path.
- Record source path, extracted text path, page count if available, and date.
- If extraction is partial, say so and proceed with the available text rather than hallucinating missing sections.

### 2. Create a durable knowledge base

Default location:

```text
/opt/data/knowledge_bases/<slug>/
```

Recommended files:

```text
README.md
01-core-philosophy-and-principles.md
02-business-pipeline.md
03-prospecting-and-recruiting.md
04-fast-start-and-first-30-days.md
05-sales-and-client-process.md
06-leadership-duplication-and-training.md
07-coaching-operating-system.md
08-source-index.md
```

For other domains, rename modules but keep the same idea: philosophy, process, action plan, operating system, source index.

### 3. Translate old playbooks into modern, ethical practice

Many sales playbooks contain aggressive or outdated language. Keep the useful structure but modernize the behavior:

- Use consultative selling and diagnosis.
- Avoid pressure, misleading claims, income promises, or regulated product claims.
- Use scripts as conversation guides, not manipulation.
- Make every claim verifiable.
- Use automation for follow-up and accountability, not spam.
- Add compliance cautions when the source includes finance, insurance, investment, medical, legal, or tax topics.

### 4. Build the coaching operating system

For every coaching KB, define:

- Daily check-in questions
- Weekly review questions
- Pipeline stages
- Scoreboard metrics
- Scripts or prompts
- Follow-up cadence
- Bottleneck diagnosis
- Next-step decision rules

Default daily coaching questions:

- What is today’s main business objective?
- How many new prospects/leads will be added?
- How many calls/messages will be sent?
- Which follow-ups are overdue?
- How many discovery calls or appointments are booked?
- Which proposal/demo/pilot must move forward?
- Who needs training/onboarding?
- What is the bottleneck: leads, outreach, appointment, close, delivery, or follow-up?

### 5. Convert the playbook into a sales process

Use this pattern unless the source requires another:

1. Prospect / identify target
2. Contact / invite
3. Discovery / collect information
4. Diagnose bottleneck
5. Recommend one focused solution
6. Offer a low-risk pilot or next step
7. Implement quickly
8. Follow up and ask for referrals
9. Convert to ongoing relationship
10. Train others to duplicate

### 6. Create fast-start plans

Fast start should be exact, not motivational:

- Exact offer
- Exact lead list target
- Exact script
- Exact daily activity number
- Exact event/demo/workshop target
- Exact trainer/accountability person
- Exact 7-day and 30-day scoreboard

### 7. Add event/showcase strategy when relevant

For consultative or service businesses, convert weekly meetings into a lead engine:

- Weekly free showcase or workshop
- Educational topic
- Live demo
- Specialist/engineer panel
- Free diagnosis CTA
- 7-day paid pilot CTA
- Same-day follow-up
- 48-hour proposal cadence

### 8. Verify and remember only durable facts

- Verify files were written by listing or reading the KB before finalizing.
- Save durable user preference/context to memory only when it will matter beyond the week.
- Do not save one-off task progress, PRs, issue numbers, or transient artifacts in memory.

## Output style

For Telegram/mobile users:

- Prefer headings and bullets over tables.
- Keep action plans practical and direct.
- Use Mongolian when the user speaks Mongolian or the business context is Mongolia-focused.
- Give concrete scripts, checklists, and numerical targets.

## Linked references

- `references/team-pinnacle-agenticforce.md` — session-specific reference: Team Pinnacle Playbook II translated into AgenticForce AI agents business coaching, sales process, weekly showcase, and closing questions.
