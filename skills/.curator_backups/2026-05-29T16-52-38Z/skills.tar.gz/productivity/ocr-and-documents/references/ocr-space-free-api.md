# OCR.space Free API — Zero-Dependency OCR Fallback

## When to Use

When no local OCR tools are installed (no tesseract, no marker-pdf, no pip), and you need to extract text from a JPEG/PNG image. The OCR.space free API requires nothing but `curl` or `urllib` — no packages, no models, no installs.

## API Details

- **Endpoint:** `https://api.ocr.space/parse/image`
- **Free API key:** `helloworld` (demo key, rate-limited but works for occasional use)
- **Engine:** `OCREngine=2` (best accuracy)
- **Free tier:** 500 requests/month, ~10 req/10s rate limit

## Request Pattern (Python via urllib)

```python
import base64, json, urllib.request, urllib.parse

with open('image.jpg', 'rb') as f:
    img_b64 = base64.b64encode(f.read()).decode()

data = urllib.parse.urlencode({
    'base64Image': f'data:image/jpeg;base64,{img_b64}',
    'language': 'eng',
    'OCREngine': '2',
}).encode()

req = urllib.request.Request(
    'https://api.ocr.space/parse/image',
    data=data,
    headers={
        'apikey': 'helloworld',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
)

resp = urllib.request.urlopen(req, timeout=30)
result = json.loads(resp.read())
text = result['ParsedResults'][0]['ParsedText']
```

## Limitations

- **Image size limit:** ~1MB for free tier
- **Language support:** eng, mongolian, 20+ others
- **No layout preservation:** returns flat text, no tables/columns
- **Rate limited:** 10 requests per 10 seconds
- **Cyrillic accuracy:** Good for printed text, poor for handwriting
- **Free key may change:** `helloworld` is a well-known demo key; if it stops working, register at https://ocr.space for a free API key

## When Not to Use

- Need table detection → marker-pdf
- Need layout/reading order → marker-pdf
- Processing many documents → install tesseract locally
- Text-only PDF → use pymupdf (faster, local)
