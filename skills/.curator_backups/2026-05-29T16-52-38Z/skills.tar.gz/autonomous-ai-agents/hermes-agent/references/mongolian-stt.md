# Mongolian STT for Telegram gateway

Use this when the user wants to speak Mongolian voice messages to Hermes through Telegram or another gateway platform.

## Key findings

- Local `faster-whisper` with the `base` model may technically work but often produces poor Mongolian transcripts, especially from compressed Telegram voice messages and mixed Mongolian/English speech.
- For Mongolian, force language detection to Mongolian when possible:

```yaml
stt:
  enabled: true
  provider: local
  local:
    model: medium
    language: mn
```

- Model quality/load tradeoff for CPU-only small servers:
  - `small` + `language: mn`: lightest practical test, lower load, may still miss words.
  - `medium` + `language: mn`: best first recommendation for a 2-core/8GB class server.
  - `large-v3` + `language: mn`: best local quality, but can create high CPU spikes and several GB RAM pressure on CPU-only servers.

## Recommended decision sequence

1. Check current live STT config and gateway status.
2. Verify `faster_whisper` imports in the exact Python used by the gateway.
3. If current model is `base`, upgrade in stages rather than jumping straight to `large-v3` on a small CPU server:
   1. `small`, forced `mn`
   2. `medium`, forced `mn`
   3. cloud STT such as Groq/OpenAI/Mistral if latency or CPU load is unacceptable
   4. `large-v3`, forced `mn`, only if local/private quality matters more than speed/load
4. Restart the gateway after config changes.
5. Test with several realistic voice messages: short commands, longer instructions, pure Mongolian, and Mongolian with English technical words.

## Resource guidance

Before recommending `large-v3`, check server CPU/RAM/swap/disk. On a 2-core CPU-only server with ~8GB RAM and no swap:
- expect high CPU during transcription;
- expect slower transcription for long voice messages;
- expect extra RAM pressure when the model is loaded;
- short commands may be acceptable, but long audio can make the gateway feel delayed.

Cloud STT options reduce server load but send audio to the provider and require API keys:
- Groq Whisper: fast, often practical for small servers, free tier/rate limits may apply.
- OpenAI Whisper: reliable paid option.
- Mistral Voxtral: worth testing for Mongolian, quality should be verified.

## User-facing explanation pattern

Keep the recommendation practical:
- "Your current local base model is too weak for Mongolian; the first fix is forcing `language: mn` and testing `small` or `medium`."
- "`large-v3` gives better quality but is heavy on a 2-core server; use it only if you accept slower responses or need local/private STT."
- "If you want less server load, use a cloud STT provider."
