# Stale gateway platform locks

Use this when a Hermes Gateway platform reports that a credential/token is already in use, but process inspection shows the referenced PID is gone or zombie.

## Symptom

Gateway status or logs show a platform-specific lock error, for example:

```text
telegram: Telegram bot token already in use (PID 1314). Stop the other gateway first.
[Telegram] Telegram bot token already in use (PID 1314). Stop the other gateway first.
```

The global gateway may still run with other platforms, e.g. webhook only, while Telegram fails to connect.

## Verify before touching locks

1. Check gateway status:

```bash
/opt/hermes/.venv/bin/python /opt/hermes/hermes gateway status || hermes gateway status
```

2. Inspect the claimed PID and current gateway processes:

```bash
ps -o pid,ppid,stat,etime,cmd -p <PID>
ps aux | grep -E '[h]ermes.*gateway|[p]ython.*gateway'
```

Only treat the lock as stale if the PID is absent or has zombie status (`STAT` starts with `Z`). If a real non-zombie gateway process is running, stop that gateway instead of deleting the lock.

## Lock locations

Platform credential locks live under:

```text
$HERMES_HOME/.local/state/hermes/gateway-locks/
```

Examples:

```text
/opt/data/.local/state/hermes/gateway-locks/telegram-bot-token-<hash>.lock
```

The profile gateway PID/lock files are separate:

```text
$HERMES_HOME/gateway.pid
$HERMES_HOME/gateway.lock
```

Do not confuse the profile-wide gateway lock with a platform credential lock.

## Safe cleanup pattern

Quarantine stale platform locks rather than deleting them outright:

```bash
/opt/hermes/.venv/bin/python - <<'PY'
import json, pathlib, subprocess, datetime
base = pathlib.Path('/opt/data/.local/state/hermes/gateway-locks')
for p in base.glob('telegram-bot-token-*.lock'):
    data = json.loads(p.read_text())
    pid = str(data.get('pid'))
    stat = subprocess.run(['ps', '-o', 'stat=', '-p', pid], text=True, capture_output=True).stdout.strip()
    stale = (not stat) or stat.startswith('Z')
    if stale:
        new = p.with_name(p.name + '.stale.' + datetime.datetime.now().strftime('%Y%m%d%H%M%S'))
        p.rename(new)
        print(f'quarantined stale lock {p.name} pid={pid} stat={stat!r}')
    else:
        print(f'active lock remains {p.name} pid={pid} stat={stat!r}')
PY
```

Adjust the glob for other platform credential locks if needed.

## Restart and verify

Start the gateway in a way that will not be killed by the tool timeout. For live debugging from the agent, use `terminal(background=true)` rather than a foreground restart command that can be terminated when the tool times out.

Then verify logs contain:

```text
[Telegram] Connected to Telegram (polling mode)
gateway.run: ✓ telegram connected
gateway.run: ✓ webhook connected
gateway.run: Gateway running with 2 platform(s)
```

If a foreground restart was accidentally timed out, it may leave another stale platform lock for the short-lived PID. Re-run the stale-lock verification before starting again.
