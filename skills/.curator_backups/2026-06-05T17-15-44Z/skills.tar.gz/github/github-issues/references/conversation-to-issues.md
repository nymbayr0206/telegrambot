# Converting Conversation Notes to GitHub Issues

## When to Use

The user says something like: "I had memory notes from that Friday conversation — save them as GitHub issues" or "find my notes about project changes and create issues for them."

## Workflow

### 1. Find the source conversation

Use `session_search` with keywords from what the user remembers (date, topic, person mentioned, project name). If the first search fails, try progressively broader terms.

### 2. Extract action items

Read the session transcript (especially the last portion) to identify concrete action items, fix requests, or change tasks. Look for:

- User saying "I need to fix X, change Y, add Z"
- User mentioning feedback from someone (lawyer, client, partner)
- Bullet lists of tasks the user asked to do
- GitHub issues that were already discussed but not created yet

### 3. Identify the target repo

From `gh repo list` — ask the user which repo if ambiguous, or infer from context:
- `tengertech-webapp` — money-ciple financial system
- `tengertecherp` — municipal ERP (хот тохижилт)
- `agenticforceweb` — agenticforce company site/product
- `postly.mn` / `postlyautovideo` — postly brand
- `supernova.mn` — supernova brand

### 4. Create issues in batch

Use `gh issue create` for each item. Apply appropriate labels (documentation, bug, enhancement) based on the task type.

### 5. Example: From conversation → issues

Source: Friday session about a "хөгжүүлэлтийн ажлын тайлан" (development report).

Lawyer's feedback → 4 issues: late reason + actual date; fix section 5 user roles; remove purchasing manager role, add Нярав; department head signatures.

Each gets its own issue with STATUS note:
```bash
gh issue create --repo owner/repo --title "Fix: Description" --label "documentation" --body "Context and status info"
```

### 6. Verify

Run `gh issue list --repo owner/repo` to confirm all issues were created.

## Pitfalls

- Don't create one issue with a list of items. Each action item gets its own issue.
- Include source context in the issue body so it's clear where the task came from.
- Mark "already done" status if the change was already applied (e.g., "Баасан гарагт засвар хийгдсэн ✅").
- Use descriptive Mongolian titles when the context is about Mongolian project documentation — it helps the user find issues later.
- For documentation fixes, use the `documentation` label. For code changes, use `bug` or `enhancement`.
