---
name: espocrm-api
category: crm-and-sales
description: EspoCRM REST API reconnaissance, authentication, entity discovery, and data operations. Covers API key vs session auth, custom entity detection via Settings endpoint, HTTP status code semantics, and common CRUD patterns for EspoCRM instances.
---

# EspoCRM REST API

Use this skill when connecting to or exploring an unknown EspoCRM instance, troubleshooting API access issues, or building integrations with EspoCRM.

## Quick Start

```bash
# Test connection
curl -s "http://<host>:<port>/api/v1/" -H "X-Api-Key: <key>"
# Returns: "EspoCRM REST API"

# Get instance name & full entity list
curl -s "http://<host>:<port>/api/v1/Settings" -H "X-Api-Key: <key>"
# Returns: applicationName, tabList (all entities including custom), globalSearchEntityList, quickCreateList
```

## Authentication Methods

### Method 1: API Key (X-Api-Key header) — Preferred
```bash
curl -H "X-Api-Key: <api_key>" http://<host>:<port>/api/v1/Entity
```
- Best for automated/read-only access
- Roles are managed via Administration > API Keys in the web UI

### Method 2: Session Token (AuthToken endpoint)
```bash
# Login to get a token
TOKEN=$(curl -s -X POST "http://<host>:<port>/api/v1/AuthToken" \
  -H "Content-Type: application/json" \
  -d '{"userName":"admin","password":"<pass>"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

# Use the token
curl -H "Authorization: Bearer $TOKEN" http://<host>:<port>/api/v1/Lead
```
- Full admin CRUD access if admin credentials are used
- Token expires after session timeout

## HTTP Status Code Semantics

| Code | Meaning | X-Status-Reason |
|------|---------|-----------------|
| 200 | Success — data returned | — |
| 401 | Unauthorized — wrong auth method or credentials | — |
| 403 | Forbidden — auth recognized but no permission | `No read/create/delete access.` or `No access to 'Entity'.` |
| 404 | Not Found — entity doesn't exist on this instance | — |
| 500 | Server error — entity exists but internal error | — |

## Entity Discovery Strategy

### 1. Try common entities
```bash
for e in Account Contact Lead Opportunity Case User Note Meeting Call Task Document; do
  code=$(curl -so /dev/null -w "%{http_code}" "http://<host>/api/v1/$e" -H "X-Api-Key: <key>")
  echo "$e: $code"
done
```

### 2. Read Settings endpoint for custom entities
The `/api/v1/Settings` endpoint exposes the full configured entity list including custom entities:
- `tabList` — all entities shown in the UI tabs (definitive list)
- `globalSearchEntityList` — entities included in global search
- `quickCreateList` — entities in the quick-create menu

### 3. Common Real-Estate custom entities
```bash
RealEstateProperty    # Properties/listings
RealEstateRequest     # Buyer/tenant requests
```

## Creating & Updating Records

### POST — Create new record
```bash
curl -s -X POST "http://<host>/api/v1/RealEstateRequest" \
  -H "X-Api-Key: <key>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Яармаг 3 өрөө",
    "description": "📞 99667788\n📍 Яармаг\n🏠 3 өрөө байр\n💰 500M төсөв",
    "type": "Sale",
    "propertyType": "Apartment",
    "fromBedroomCount": 3,
    "status": "New"
  }'
# Returns 200 with the new record including auto-generated ID and name
```

### PUT — Update existing record
```bash
curl -s -X PUT "http://<host>/api/v1/RealEstateRequest/<id>" \
  -H "X-Api-Key: <key>" \
  -H "Content-Type: application/json" \
  -d '{"status": "In Progress", "assignedUserId": "<user_id>"}'
```

### Currency fields — MUST set both value and currency in the SAME request
```bash
# ✅ CORRECT — works
curl -X PUT ".../RealEstateRequest/<id>" \
  -H "Content-Type: application/json" \
  -d '{"fromPrice": 500000000, "fromPriceCurrency": "USD"}'

# ❌ WRONG — all fail with "validCurrency" validation error
curl -X PUT ".../RealEstateRequest/<id>" \
  -d '{"fromPrice": 500000000}'              # No currency code
curl -X PUT ".../RealEstateRequest/<id>" \
  -d '{"fromPriceCurrency": "USD"}'           # Value not set yet
curl -X PUT ".../RealEstateRequest/<id>" \
  -d '{"fromPrice": {"value": 500000000, "currency": "USD"}}'  # Object format
```

The `fromPriceCurrency` field must be in the instance's allowed currency list (check `currencyList` in `/api/v1/Settings`).

Version note: This quirk affects custom entity currency fields in EspoCRM 9.x. Standard entities (Opportunity.amount) accept plain integers without separate currency spec.

## EspoCRM Version Discovery

```bash
curl -s "http://<host>/api/v1/Settings" -H "X-Api-Key: <key>" | python3 -c "
import json, sys
s = json.load(sys.stdin)
print(f'Version: {s.get(\"version\", \"unknown\")}')
print(f'App: {s.get(\"applicationName\", \"unknown\")}')
print(f'Currencies: {s.get(\"currencyList\", [])}')
print(f'Timezone: {s.get(\"timeZone\", \"unknown\")}')
"
```

## Pagination, Filtering & Ordering

```bash
# Paginate
curl "...api/v1/Lead?offset=0&maxSize=20"

# Filter by date (today)
curl "...api/v1/Task?filter[0][type]=today&filter[0][attribute]=dateStart&maxSize=20"

# Filter by status
curl "...api/v1/Task?filter[0][type]=equals&filter[0][attribute]=status&filter[0][value]=Not+Started"
```

### Date Filter Types

| Type | Description |
|------|-------------|
| `today` | Matches records where `attribute` equals today's date |
| `past` | Matches records where date is in the past |
| `future` | Matches records where date is in the future |
| `between` | Matches records between two dates (requires `from` and `to`) |
| `equals` | Exact match on a field value |

## Common Pitfalls

- **API key vs Bearer token**: `X-Api-Key` header for API keys, `Authorization: Bearer` for session tokens. Don't mix them up.
- **403 vs 401**: 403 means the API key IS recognized but doesn't have permission for that entity. You need to add roles via the web UI (Administration > API Keys).
- **Empty response does not equal no data**: Always check `total` field in response. `{"total": 0, "list": []}` means genuinely empty; an empty body means 403/401 (check with `-sv`).
- **API key can't self-modify**: The API key's own permissions block it from accessing `/api/v1/ApiKey` or `/api/v1/AuthToken` unless explicitly granted. To change permissions, use admin session token or web UI.
- **No browser available**: When the server has no browser install (Docker containers), use curl for all admin operations or ask the user to make changes via the web UI.
- **Auto-numbered name fields**: Custom entities like RealEstateRequest have auto-generated read-only names (e.g. "R 000001"). PUT requests that try to change `name` will be silently ignored — the system name stays.
- **Currency field quirk (EspoCRM 9.x)**: Custom entity currency fields (`fromPrice`, `toPrice`, `price`) require BOTH the value field AND the currency code field in the SAME request. Setting just the value or setting them in separate requests fails with `validCurrency` validation error. See CRUD section for correct syntax.
- **Metadata API parity gap**: `/api/v1/metadata/entityDefs/EntityName` works for standard entities (Opportunity, Lead) but returns empty for custom entities (RealEstateProperty, RealEstateRequest). Use the Settings endpoint for entity discovery instead.
