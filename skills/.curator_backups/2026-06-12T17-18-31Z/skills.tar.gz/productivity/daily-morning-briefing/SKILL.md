---
name: daily-morning-briefing
description: "Compile and deliver a structured daily work briefing: check Odoo CRM for recent activity, review cron job status, surface ongoing projects, and present a numbered action menu. Use when the user asks 'what's my day looking like?', 'today's tasks', 'ажлын даалгавар гарга', or 'өнөөдрийн төлөвлөгөө'."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [daily-briefing, morning-check, task-list, productivity, mongolian]
    related_skills: [odoo19-query, business-sales-coaching, google-workspace, social-media-automation]
---

# Daily Morning Briefing

## Overview

When the user asks for today's tasks / work plan / daily briefing, follow this structured workflow to compile a comprehensive picture from all available sources. Designed for users with Odoo CRM, automated cron workflows, content pipelines, and sales coaching routines.

Works for both Mongolian ("өнөөдөр миний ажлын даалгавруудыг гаргаж өг") and English ("what's on today?").

## Workflow

### Step 1: Understand date/time context

Note the current UTC time and convert to the user's timezone (typically Asia/Ulaanbaatar, UTC+8). Lead with this in your response so the user knows you have the right day.

### Step 2: Gather recent context (parallel)

Run these in parallel where possible:

```python
# Tool calls - do these together
session_search()  # no query → recent sessions
cronjob(action='list')
memory -> read user profile
```

### Step 3: Query Odoo for recent activity (7-day window)

If the user has Odoo access, always pull fresh data. Use the `odoo19-query` skill. The 7-day UTC window for ULAT (UTC+8) users:

**Start:** `YYYY-MM-DDT16:00:00` (7 days ago at midnight ULAT)
**End:** `YYYY-MM-DDT16:00:00` (today at midnight ULAT)

```bash
# New modules installed
python3 /opt/data/skills/productivity/odoo19-query/scripts/odoo_query.py search-read ir.module.module \
  --domain '[["state", "=", "installed"], ["create_date", "!=", false], ["create_date", ">=", "START_UTC"]]' \
  --fields name,display_name,create_date --limit 20 --order 'create_date desc'

# New CRM leads (most important — user asks for "утас нэрийг гарга")
python3 /opt/data/skills/productivity/odoo19-query/scripts/odoo_query.py search-read crm.lead \
  --domain '[["create_date", ">=", "START_UTC"]]' \
  --fields name,contact_name,partner_name,phone,email_from,create_date \
  --limit 50 --order 'create_date desc'

# New partners/contacts
python3 /opt/data/skills/productivity/odoo19-query/scripts/odoo_query.py search-read res.partner \
  --domain '[["create_date", ">=", "START_UTC"]]' \
  --fields name,phone,email,create_date \
  --limit 50 --order 'create_date desc'
```

### Step 4: Compile structured briefing

**Format (proven to work for Mongolian users):**

1. **Header** — Date + Day + Time in ULAT
2. **Odoo results section** — Use ✅ emoji header, table format:
   - Modules: count + "Шинээр суулгасан модуль байхгүй" or list
   - CRM Leads: count + table with #, company/name, phone
   - Partners: note if they're test entries vs real
3. **Cron job status** — Flag any jobs with `last_status = "error"` — these need attention
4. **Ongoing projects table** — Brief status per project/brand
5. **Goal reminders** — OOS / 1M M&T, sales coaching schedule
6. **Numbered action menu** — Offer 5-8 specific choices the user can pick from

### Step 5: End with an open call to action

Use "Юу хийхээ хэлээд өгөөч 👇" (Mongolian) or "What would you like to tackle?" (English).

## Formatting Rules

- Use emoji section headers (🔥, ✅, 📋, etc.) for visual scanning on Telegram
- Use markdown tables → convert to **bullet lists** (Telegram has no table syntax):
  ```
  • **Company** — Name | Phone: 99XXXXXX
  ```
- Number the action items (1️⃣ 2️⃣ 3️⃣) for easy reference
- Lead with the freshest/most important data
- Flag cron errors prominently — the user may not know they exist

## Extended flow: Assigning tasks to team members

When someone asks "хүн тус бүр дээр даалгавар үүсгэх" (create tasks for each person), "ажилтан бүрт task өгөх", or "даалгавар хуваарилах" — this is **task assignment**, not daily briefing compilation.

### Step 1: Resolve ambiguity

The user may just say "хүн бүрт даалгавар" without specifying:
- **Which people** — team name? All Odoo users? Specific role?
- **What tasks** — what work needs doing? Is it known from a prior conversation?
- **Where to create them** — Odoo project.task? Linear? Kanban board? Google Sheets?

**Default assumption:** If the context is the "My office" group and the user frequently mentions Odoo, default to Odoo `project.task` unless another system is explicitly named. Confirm in 1 sentence rather than a full interrogation.

**Mongolian phrasing patterns:**
- "хүн тус бүр дээр даалгавар үүсгэж болгох" = "make it so tasks are created for each person" (they want the mechanism/process set up, not one-off tasks)
- "даалгавар хуваарилах" = "assign/distribute tasks" (one-time assignment)
- "ажилтан бүрт task өгөх" = "give a task to each employee"

The first pattern ("үүсгэж болгох") may mean they want an automated system or recurring process set up — ask if they mean a one-time task creation or a recurring/automated process.

### Step 2: Discover people from Odoo

If the people are Odoo users/employees, query their active internal users:

```bash
python3 /opt/data/skills/productivity/odoo19-query/scripts/odoo_query.py search-read res.users \
  --domain '[[\"active\", \"=\", true], [\"share\", \"=\", false]]' \
  --fields id,name,login,employee_id \
  --limit 100 --order 'name asc'
```

If the people are from a specific department or project team, query `hr.employee`:

```bash
python3 /opt/data/skills/productivity/odoo19-query/scripts/odoo_query.py search-read hr.employee \
  --domain '[[\"active\", \"=\", true]]' \
  --fields id,name,job_title,department_id,work_phone \
  --limit 100 --order 'name asc'
```

### Step 3a: Create tasks in Odoo (one-time assignment)

For one-time task creation per person, use XML-RPC `project.task` create via terminal() (not execute_code — the sandbox lacks .env):

```bash
python3 << 'PYEOF'
import os, xmlrpc.client
url = os.environ.get('ODOO19_URL')
db = os.environ.get('ODOO19_DB')
user = os.environ.get('ODOO19_USER')
password = os.environ.get('ODOO19_PASSWORD')
common = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/common')
uid = common.authenticate(db, user, password, {})
models = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/object')

persons = [
    {"name": "Person 1", "user_id": 2, "task": "Task description"},
    {"name": "Person 2", "user_id": 3, "task": "Another task"},
]
for p in persons:
    task_id = models.execute_kw(db, uid, password, 'project.task', 'create', [{
        'name': p['task'],
        'user_ids': [(4, p['user_id'])],
        'project_id': PROJECT_ID,  # required
        'description': f"Assigned to {p['name']}",
    }])
    print(f"Created task {task_id} for {p['name']}")
PYEOF
```

**Required fields for `project.task`:** `name` (title) and `project_id` (project). `user_ids` is optional but that's how you assign it to a person. Discover available projects first:

```bash
python3 /opt/data/skills/productivity/odoo19-query/scripts/odoo_query.py search-read project.project \
  --domain '[[\"active\", \"=\", true]]' \
  --fields id,name --limit 50
```

### Step 3b: Set up an automated/recurring process

If the user wants "үүсгэж болгох" (make it so tasks are created automatically), this means setting up a cron job or workflow. Options:

- **Hermes cron job** that runs daily/weekly and creates tasks via Odoo XML-RPC
- **Odoo automated action** (server action + base action rule)
- **Odoo recurring task** via the project.task.recurrence model (if installed)

For Hermes cron, offer to create a script like:

```bash
# /opt/data/scripts/create_daily_tasks.py
# Reads a task list from a config or Google Sheet
# Creates project.task for each person via Odoo XML-RPC
```

Then schedule it with `cronjob(action='create', schedule='0 1 * * *', script='/opt/data/scripts/create_daily_tasks.py')`.

### Step 4: Report back

**One-time assignment:** Confirm what was created — task IDs, assignee names, and task titles.

**Process creation:** Confirm what was set up and how it works — "Өдөр бүр 09:00 цагт Odoo дээр ажилтан бүрт даалгавар автоматаар үүсгэгдэхээр тохирууллаа."

## Pitfalls

- **Odoo installs vs updates:** Modules installed during initial DB creation have `create_date: false`. Only custom modules added later have timestamps. Query with `["create_date", "!=", false]` to filter.
- **res.partner vs crm.lead:** New contacts in `res.partner` are often test entries or system-generated — `crm.lead` is where real prospect data lives. Prioritize leads.
- **Don't use tables in Telegram:** The platform has no table syntax. Use pipe tables only if you know they get auto-rewritten; otherwise use bullet lists.
- **UTC conversion:** Odoo stores `create_date` in UTC. For ULAT (UTC+8), today's data is from `YYYY-MM-DDT00:00:00+08:00` = `YYYY-MM-DD-1T16:00:00Z`.
- **CRM lead "phone" field can have spaces:** Some phone values include spaces like "8888 0312" — don't strip them when presenting.
- **User is direct-execution oriented:** Don't over-explain or ask clarifying questions. Present the data and let them pick.
- **"Хүн бүрт даалгавар" ambiguity:** Don't assume you know who the people are or what the tasks are. The user may be referring to CRM leads (create follow-up tasks), team members (assign daily work), or external contacts (send tasks/offers). Ask specifically: which people? what tasks? which system?
- **`execute_code` vs `terminal` for Odoo writes:** `execute_code` sandbox doesn't load .env vars (ODOO19_URL etc. return None). Always use `terminal()` with `python3 << 'PYEOF'` for XML-RPC write operations.
- **project.task `project_id` is required:** Unlike `crm.lead`, you can't create a `project.task` without specifying which project it belongs to. Discover projects first.
- **Recurring vs one-shot phrasing:** "үүсгэж болгох" ≈ "make it so it gets created" suggests automation/process setup, not a one-time batch. "үүсгэж өгөх" or "өгөх" means one-time. Listen for the distinction.
