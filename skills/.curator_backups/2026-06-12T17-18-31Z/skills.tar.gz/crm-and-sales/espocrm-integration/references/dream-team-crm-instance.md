# Dream Team CRM Instance

| Property | Value |
|---|---|
| **URL** | http://187.77.140.62:32769/ |
| **API Base** | http://187.77.140.62:32769/api/v1/ |
| **API Key** | `e9a86a254bf03ff29c220e2c63c9b0f1` |
| **Auth Header** | `X-Api-Key` |
| **EspoCRM Version** | 9.3.8 |
| **Name** | Dream Team crm |
| **Type** | Real Estate CRM |

## Users

| ID | Name | Username | Role |
|---|---|---|---|
| `6a2bba573119bd70e` | Admin | admin | admin |
| `6a2bbef6a311a0b49` | Lana lana | lanaceoclub | regular (realtor) |

## Currency

Only **USD** is configured in `currencyList`. MNT is not supported — all amounts are in USD.

## Current Records (as of 2026-06-12)

### RealEstateProperty (2)
1. **unknown-address** — Land Lot, Sale, New, no price
2. **13-р гудамж, УБ** — Separate House, Sale, 1B MNT, 5 bed

### RealEstateRequest (2 active)

| # | Phone | Location | Type | Budget | Notes |
|---|---|---|---|---|---|
| **R 000001** | 99667788 | Яармаг | Sale, 3 өрөө | 500M USD | Created 2026-06-12 |
| **R 000003** | 80001059 | Хан-Уул | Rent, 3 өрөө | — | ⏰ Follow-up **2026-06-26** (client in countryside) |

### Leads (2)

| ID | Name | Phone | Status | Source |
|---|---|---|---|---|
| `6a2c0a369e113d9b4` | 80001059 Хан-Уул | +97680001059 | New | Call |
| `6a2c0a52aec85f286` | 99667788 Яармаг | +97699667788 | New | Call |

### Tasks (1 active)

| ID | Name | Due | Priority |
|---|---|---|---|
| `6a2c08f0ca03c48f6` | 80001059 руу залгах - Хан-Уул 3 өрөө түрээс | 2026-06-26 09:00 | High |

### Cron Jobs (2)

| Name | Schedule | Purpose |
|---|---|---|
| Өглөөний CRM Task сануулга | Daily 00:00 UTC (08:00 ULAT) | Check EspoCRM tasks due today → Telegram reminder |
| 80001059 руу залгах сануулга | One-shot 2026-06-26 01:00 UTC (09:00 ULAT) | Specific follow-up reminder |

### Opportunity (1)
- **unnamed** — 650M, Prospecting, close 2026-06-19
