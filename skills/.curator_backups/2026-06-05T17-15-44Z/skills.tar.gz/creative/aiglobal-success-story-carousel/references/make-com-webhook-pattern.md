# Make.com Webhook Pattern — AI Global Poster Delivery

## Webhook URL
```
https://hook.eu1.make.com/xb37pnxrn674ngf8ixurm4eoj1pdf21e
```

## Protocol

**Always send as multipart form-data**, not JSON. Base64-encoded JSON payloads exceed Make.com's size limit ("request entity too large" — 400 error).

## Single-Request (Preferred) — All 4 Posters at Once

Make.com's Facebook integration accepts up to 4 posters in one request:

```bash
curl -s -X POST "$WEBHOOK_URL" \
  -F "image1=@poster1.png;type=image/png" \
  -F "image2=@poster2.png;type=image/png" \
  -F "image3=@poster3.png;type=image/png" \
  -F "image4=@poster4.png;type=image/png" \
  -F "caption1=🔥 AI Vibe Coder first caption..." \
  -F "caption2=🚀 Second caption..." \
  -F "caption3=🌍 Third caption..." \
  -F "caption4=✨ Fourth caption..." \
  -F "total_posters=4" \
  -F "source=hermes_agent" \
  -F "brand=AI Global"
```

## Per-Poster (Alternative)

If only 1-2 posters need updating:

```bash
curl -s -X POST "$WEBHOOK_URL" \
  -F "image=@poster1.png;type=image/png" \
  -F "caption=🔥 Text caption here..." \
  -F "poster_number=1" \
  -F "total_posters=1" \
  -F "source=hermes_agent" \
  -F "brand=AI Global"
```

## Caption Format

Captions should be in Mongolian Cyrillic, including:
- Emoji leading (🔥 🚀 🌍 ✨)
- Poster-specific content summary
- CTA (Бүртгүүлэх утас: 89097454)
- Hashtags optional (#AIVibeCoder, #AIGlobal)

## Response

- `"Accepted"` — received successfully
- `"request entity too large"` — switch from JSON/base64 to multipart
- No response / 404 — webhook may be offline
