# VPS Gateway Inspection

When you SSH into a Hermes VPS and need to understand the running state — where the gateway lives, what port it's on, whether it's a service or foreground process, and what webhook config it has — use this reconnaissance recipe.

## 1. Check if Gateway is Running

```bash
# Check gateway status via Hermes CLI
hermes gateway status

# Alternative: find the actual process
ps aux | grep -v grep | grep "hermes gateway"
```

Look for either:
- `hermes gateway run` — foreground/manual mode
- `hermes gateway` — systemd service (check with `systemctl --user status hermes-gateway`)

## 2. Find Running PIDs and Process Type

```bash
# Full process list with parent info
ps aux | grep -E "hermes|python"

# Check if systemd service
systemctl --user list-units --type=service --all 2>/dev/null | grep -i hermes
systemctl list-units --type=service --all 2>/dev/null | grep -i hermes

# Check for docker
docker ps 2>/dev/null | grep -i hermes

# Check cron jobs
hermes cron list
```

Key distinction:
- `runuser -u hermes -- env ... hermes gateway run` → manually started
- `systemctl` shows systemd service
- Missing both → probably in Docker

## 3. Find the hermes Binary and Version

```bash
which hermes 2>/dev/null
hermes --version
```

Source installs: binary lives in `.venv/bin/hermes` under the project root.

## 4. Locate Config and Data

```bash
# Print config path
hermes config path 2>/dev/null

# Print env path
hermes config env-path 2>/dev/null

# Fallback: check common locations
echo "$HERMES_HOME"
ls ~/.hermes/config.yaml 2>/dev/null
ls /opt/data/config.yaml 2>/dev/null
```

Config.yaml contains all settings. `.env` (same directory) contains API keys.

## 5. Find What Port the Gateway Listens On

```bash
# Modern systems (ss is preferred but may be missing in minimal containers)
cat /proc/net/tcp 2>/dev/null | awk '{print $2}' | grep -v "local_address"

# Decode hex port to decimal: echo $((0x21C4)) = 8644
# Or just send the hex to python
python3 -c "
import re
with open('/proc/net/tcp') as f:
    for line in f:
        local = line.split()[1]
        ip, port_hex = local.split(':')
        port = int(port_hex, 16)
        state = line.split()[3]
        if state == '0A':  # LISTEN
            print(f'Port {port} LISTEN')
"
```

Common Hermes ports:
- 8644 — webhook platform (gateway)
- 4860 — ttyd web terminal
- 8890 — image cache HTTP server
- 8899 — dashboard HTTP server

## 6. Check Webhook Platform Config

From `config.yaml`, look for:

```yaml
platforms:
  webhook:
    enabled: true
    extra:
      host: 0.0.0.0
      port: 8644
      secret: <sha256-secret>
```

Health check:
```bash
curl -s http://localhost:8644/health
# Expected: {"status":"ok","platform":"webhook"}
```

## 7. Check Telegram Status

Telegram runs inside the gateway (long-polling, not webhook). Verify from config:

```yaml
platforms:
  telegram:
    enabled: true
    token: 1234567890:...
```

The gateway connects to Telegram API directly — no Telegram webhook setup needed.

## 8. Check for Zombie Processes

Hermes spawns many browser/tool subprocesses. Zombies are common and mostly harmless:

```bash
ps aux | grep -w Z
# Z = defunct (zombie), ZN = defunct + nice
```

If there are too many, the parent process (PID 1 or gateway PID) needs to `wait()` for them. A gateway restart cleans them up.

## 9. Find the Telegram Bot Token (Redacted)

```bash
grep -A2 "telegram:" /opt/data/config.yaml 2>/dev/null | grep token
# Output will be redacted in most shells as ****
```

## Quick Summary Command

```bash
echo "=== HERMES VPS DIAGNOSTIC ==="
echo "Binary: $(which hermes 2>/dev/null || echo 'not found')"
echo "Version: $(hermes --version 2>/dev/null || echo 'unknown')"
echo "Config: $(hermes config path 2>/dev/null || echo 'unknown')"
echo "Gateway status: $(hermes gateway status 2>/dev/null | head -1)"
echo "Gateway PIDs: $(ps aux | grep -v grep | grep 'hermes gateway' | awk '{print $2}' | tr '\n' ' ')"
echo ""
echo "=== LISTENING PORTS ==="
python3 -c "
import re
with open('/proc/net/tcp') as f:
    for line in f:
        local = line.split()[1]
        ip, port_hex = local.split(':')
        port = int(port_hex, 16)
        state = line.split()[3]
        if state == '0A':
            print(f'  Port {port} LISTEN')
" 2>/dev/null || echo "  (cannot read /proc/net/tcp)"
echo ""
echo "=== CRON JOBS ==="
hermes cron list 2>/dev/null || echo "  (no cron access)"
echo ""
echo "=== WEBHOOK HEALTH ==="
curl -s http://localhost:8644/health 2>/dev/null || echo "  (gateway not responding on port 8644)"
```
