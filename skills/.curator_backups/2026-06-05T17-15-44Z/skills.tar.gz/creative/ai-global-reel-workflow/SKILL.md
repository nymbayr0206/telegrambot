---
name: ai-global-reel-workflow
description: AI Global reel generation — reeltemp1 scenes + dialogue V3 voiceover + TikTok captions. Always ask user for approval before each step.
---

# AI Global Reel Workflow (Consistent Rules)

**Always confirm with the user before starting any step.** Never generate without approval.

## Step 1: Plan & Get Approval

Present the reel plan: scene descriptions, voiceover text, duration. Wait for user approval.

## Step 2: Scene Images

Use KIE `gpt-image-2-image-to-image`:
- Model: `gpt-image-2-image-to-image`
- Aspect: `9:16`
- Background: `reeltemp1` (assets/reeltemp1.jpg) — MUST keep it EXACTLY as-is
- For instructor scenes: input_urls = [reeltemp1_url, instructor_photo_url]
- For other scenes: input_urls = [reeltemp1_url]
- Resolution: omit (default works)
- NO text on images — captions added by FFmpeg

## Step 3: Voiceover

Use KIE `elevenlabs/text-to-dialogue-v3`:
```
model: elevenlabs/text-to-dialogue-v3
input:
  dialogue:
    - text: "..."
      voice: "Lily"
```
- Split text into dialogue entries matching scene structure
- Total chars ≤ 5000

## Step 4: Captions (TikTok Style)

SRT format with word-chunk animation:
- Font: Manrope-Bold (~/.fonts/manrope/Manrope-Bold.ttf)
- FontSize: 10
- PrimaryColour: yellow (`&H0000FFFF`)
- OutlineColour: black (`&H00000000`)
- Outline: 0.5 (thin)
- Alignment: 2 (bottom center)
- MarginV: 40
- Split text into 2-word chunks per subtitle entry
- Each chunk timed proportionally to scene duration

## Step 5: Speed & Assembly

- Calculate `atempo` dynamically: `atempo = actual_audio_duration / target_duration`. **Default target ~40s**, so for typical ~50s VO use atempo=1.25. Always measure actual audio duration first, then calculate.
- Use FFmpeg ONLY for: merging scene images, adding audio, burning captions
- NEVER use FFmpeg for generation (images, audio)

## Step 6: Deliver

- Show final reel to user for approval
- If approved: send to Make.com webhook with `content_type=reel`
- Webhook: https://hook.eu1.make.com/xb37pnxrn674ngf8ixurm4eoj1pdf21e

## Reference Files

- `references/authority-reel-worked-example.md` — worked example from June 2026: AI CERTs + ISO standards + AI Global Authority reel. Includes full voiceover script, scene structure, research sources, and authority angles.

## Step 7: Memory

Save any new settings or corrections to memory for future consistency.
