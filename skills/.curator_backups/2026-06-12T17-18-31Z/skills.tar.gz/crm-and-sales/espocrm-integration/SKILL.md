---
name: espocrm-integration
description: "EspoCRM REST API integration — read/write entities, manage calls, tasks, real estate requests. Used for Dream Team CRM instance."
version: 1.0.0
author: Nous Research
license: MIT
platforms: [linux, macos, windows]
tags: [espocrm, crm, real-estate, api]
---

# EspoCRM Integration

EspoCRM REST API integration for reading and writing CRM entities. Targeted at the Dream Team CRM (real estate) instance but applicable to any EspoCRM 9.x instance.

## Connection

EspoCRM uses `X-Api-Key` header authentication. No session token needed unless modifying API keys.

```bash
API_KEY="your-api-key"
BASE="http://host:port/api/v1"
```

## Entity Reference

### RealEstateRequest — incoming client requests

| Field | Type | Example |
|---|---|---|
| `type` | string | `"Sale"`, `"Rent"` |
| `propertyType` | string | `"Apartment"`, `"Land Lot"` |
| `fromBedroomCount`, `toBedroomCount` | int | `3` |
| `fromPrice`, `toPrice` | int (currency) | `500000000` |
| `fromPriceCurrency`, `toPriceCurrency` | string | `"USD"` |
| `status` | string | `"New"` |
| `description` | text | Full notes |
| `parentType`, `parentId` | for linking | `"RealEstateProperty"`, ID |

### Call — phone call records

| Field | Type | Notes |
|---|---|---|
| `name` | string | Descriptive title |
| `dateStart`, `dateEnd` | datetime | `"2026-06-12 13:00:00"` |
| `durationMinutes` | int | |
| `status` | string | `"Held"`, `"Not Held"`, `"Planned"` |
| `direction` | string | `"Outbound"`, `"Inbound"` |
| `description` | text | Call notes |
| `parentType`, `parentId` | link | e.g. `RealEstateRequest`, its ID |
| `assignedUserId` | string | User UUID |

### Task — follow-up actions

| Field | Type | Notes |
|---|---|---|
| `name` | string | Task title |
| `dateStart`, `dateEnd` | datetime | |
| `status` | string | `"Not Started"`, `"Completed"` |
| `priority` | string | `"High"`, `"Normal"` |
| `parentType`, `parentId` | link | e.g. `RealEstateRequest` |
| `assignedUserId` | string | User UUID |

## Essential API Patterns

### Create a record
```bash
curl -s -X POST "$BASE/RealEstateRequest" \
  -H "X-Api-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"type":"Rent","propertyType":"Apartment","fromBedroomCount":3,"toBedroomCount":3}'
```

### Update a record (PUT)
```bash
curl -s -X PUT "$BASE/RealEstateRequest/$ID" \
  -H "X-Api-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"description":"Updated info"}'
```

### Currency field workaround (⚠️ ESSENTIAL)
In EspoCRM 9.x, currency fields on custom entities fail validation unless **both** `price` AND `priceCurrency` are set in the **same** request:
```bash
# WRONG — fails with "validCurrency" error:
curl ... -d '{"fromPrice": 500000000}' 

# RIGHT — works:
curl ... -d '{"fromPrice": 500000000, "fromPriceCurrency": "USD"}'
```
The field order matters — set both fields atomically.

### List all records
```bash
curl -s "$BASE/RealEstateRequest" -H "X-Api-Key: $API_KEY"
```

### Get single record
```bash
curl -s "$BASE/RealEstateRequest/$ID" -H "X-Api-Key: $API_KEY"
```

## Call Follow-Up Workflow

When a client call results in a scheduled follow-up (e.g. "called back in 2 weeks"):

1. **Create Call record** — POST to `/Call` with status=Held, direction=Outbound, linked to parent RealEstateRequest
2. **Update RealEstateRequest** — PUT description with latest status
3. **Create Task** — POST to `/Task` with dateStart=follow-up date, status=Not Started, priority=High, linked to parent
4. **Set cron reminder** — create a 1-time cron job for the follow-up date (morning Mongolia time, UTC+8)

```bash
# Example: Create Call
curl -X POST "$BASE/Call" \
  -H "X-Api-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Client call - description",
    "dateStart": "2026-06-12 13:00:00",
    "dateEnd": "2026-06-12 13:10:00",
    "durationMinutes": 10,
    "status": "Held",
    "direction": "Outbound",
    "description": "Notes...",
    "parentType": "RealEstateRequest",
    "parentId": "$REQUEST_ID",
    "assignedUserId": "$USER_ID"
  }'
```

## Lead Entity

For new incoming calls, create a **Lead** alongside the RealEstateRequest.

| Field | Type | Convention |
|---|---|---|
| `firstName` | string | Phone number (e.g. `"80001059"`) |
| `lastName` | string | Location (e.g. `"Хан-Уул"`) |
| `phoneNumber` | string | `+976XXXXXXXX` — MUST include country code prefix |
| `status` | string | `"New"` |
| `source` | string | `"Call"` |
| `description` | text | Full notes about the client |

### Entity Choice Guide

| Entity | When to use |
|---|---|
| **Lead** 🟡 | New caller — first contact, not yet qualified |
| **Contact** 🟢 | Known person — multiple conversations, relationship established |
| **Account** 🏢 | Organization — developer, company, real estate firm |
| **RealEstateProperty** 🏠 | Property for sale/rent (the asset) |
| **RealEstateRequest** 📋 | What the client is looking for (the need) |

### Workflow: New Call → CRM

```
📞 New call arrives:
   1. Create Lead (phone as firstName, location as lastName, +976 prefix)
   2. Create RealEstateRequest (type: Sale/Rent, bedrooms, location, budget)
   3. Link them via parentId on subsequent Call/Task records

🤝 After talking:
   1. Create Call record (status=Held, direction=Outbound/Inbound)
   2. If follow-up needed: create Task (dateStart=follow-up date, status=Not Started)
   3. Set 1-time cron job for morning-of reminder

🔄 After multiple conversations / confirmed relationship:
   → Convert Lead to Contact (or create Contact and link to requests)
```

### Phone Number Format

Phone numbers **must** use international format with `+976` (Mongolia) prefix:

```bash
# ✅ Works:
"phoneNumber": "+97680001059"

# ❌ Fails with "valid" validation error:
"phoneNumber": "80001059"
"phoneNumber": "99667788"
```

The API masks middle digits in responses (`+976****1059`) but stores the full number.

## Daily Morning Task Check (Cron Job)

Set up a daily cron job to check EspoCRM tasks due today and remind via Telegram:

```bash
# Schedule: 0 0 * * *  (00:00 UTC = 08:00 Mongolia)
# Enabled toolsets: ["terminal"]
```

The cron job should:
1. GET `/api/v1/Task` — fetch all tasks
2. Filter by `status: "Not Started"` and `dateStart` matching today (UTC+8)
3. If tasks found → send formatted Telegram reminder
4. If no tasks → return empty (silent, no message)

For API-level date filtering, use:
```
GET /api/v1/Task?filter[0][type]=today&filter[0][attribute]=dateStart&maxSize=20
```

## Pitfalls

- **Currency fields** on custom entities require price + currency in the same PUT/POST. Standard entities (Opportunity) accept plain numbers.
- **Auto-numbered names** — RealEstateRequest names are system-generated (R 000001...) and cannot be overridden via PUT.
- **403 on Query** — if you get 403, the API key may not have access to that entity. Try adding `?maxSize=1` to the URL first; some EspoCRM versions return 403 without a query parameter.
- **dateEnd required on Call** — EspoCRM requires both dateStart and dateEnd when creating Calls.
- **assignedUser required on Call** — Must include `assignedUserId` when creating Calls.
- **Phone validation** — phone numbers require `+976XXXXXXXX` format. Plain digits fail validation.
- **Lead name convention** — use phone number as `firstName`, district/location as `lastName` for quick identification.
