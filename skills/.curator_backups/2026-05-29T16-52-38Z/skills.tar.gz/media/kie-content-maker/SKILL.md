---
name: kie-content-maker
description: Use when creating social/content assets through KIE.AI APIs, especially Nano Banana 2 posters/images, Veo 3.1 Fast videos, and ElevenLabs TTS/audio. Covers prompt preparation, safe credential handling, task submission, polling, downloads, and packaging outputs for review.
version: 1.3.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [kie-ai, content-generation, posters, video, tts, nano-banana, veo, elevenlabs]
    related_skills: [youtube-content, social-media-automation, baoyu-infographic, popular-web-designs]
---

# KIE Content Maker

## Overview

Use this skill to turn a content request into generated media assets via KIE.AI. The main workflow is:

1. Clarify or infer the asset brief.
2. Build strong prompts/scripts.
3. Submit generation jobs to KIE.AI with `Authorization: Bearer $KIE_API_KEY`.
4. Poll task status until complete.
5. Convert generated KIE URLs to temporary download URLs when needed.
6. *(Optional)* Run automated quality review via OpenAI GPT-4o vision (`scripts/review_image.py`) — catches text errors, logo issues, layout problems before user delivery.
7. Save outputs locally and present paths/links for user review.

Never hardcode the user's API key into files, prompts, logs, skills, or memory. Store it in an environment variable such as `KIE_API_KEY` or a secrets manager. If the key was provided in chat, use it only for the current action and recommend rotating it if it was exposed in an unsafe place.

## Related Skills

- `brand-book-creator` — one-page brand book from a logo: analyzes colors, suggests fonts, generates 3 poster backgrounds (educational, industry leader, sales) via GPT Image 2, composites into one image with Pillow. Same KIE API + GPT Image 2 workflow, different output type.

## When to Use

Use this skill when the user asks to:

- Generate posters, ad creatives, thumbnails, social graphics, or product visuals with Nano Banana 2.
- Generate short videos with Veo 3.1, especially `veo3_fast` / Fast-style production.
- Generate narration, voiceover, dialogue, or audio using ElevenLabs models through KIE.AI.
- Build a multi-asset content pack: poster + video + voiceover + caption/script.
- Automate content generation via cron jobs using script-only (no_agent:true) pattern.
- Set up daily carousel automation that generates images and publishes via webhook.

Do not use this skill for:

- Native Hermes `image_generate` requests where the user did not mention KIE.AI.
- Direct ElevenLabs official API work outside KIE.AI.
- Social posting/publishing approval logic by itself; use `social-media-automation` alongside this skill.

## Credential Handling

Preferred setup:

```bash
export KIE_API_KEY='your_key_here'
```

Before using the API in shell commands:

```bash
test -n "$KIE_API_KEY" || { echo 'KIE_API_KEY is not set'; exit 1; }
```

Curl headers:

```bash
-H "Authorization: Bearer $KIE_API_KEY" \
-H "Content-Type: application/json"
```

Do not paste the literal key into reusable scripts, skill files, Git commits, or final answers.

## Core Endpoints

Base URL:

```text
https://api.kie.ai
```

Common job endpoint for marketplace models:

```text
POST /api/v1/jobs/createTask
GET  /api/v1/jobs/recordInfo
```

Veo 3.1 endpoints:

```text
POST /api/v1/veo/generate
GET  /api/v1/veo/record-info
POST /api/v1/veo/get-1080p-video
POST /api/v1/veo/get-4k-video
POST /api/v1/veo/extend
```

Common API:

```text
GET  /api/v1/chat/credit
POST /api/v1/common/download-url
```

Download URLs are temporary; KIE docs note generated download links may expire quickly, so download/cache outputs promptly.

## GPT Image 2 Through KIE

Use the marketplace endpoint `POST /api/v1/jobs/createTask` with model `gpt-image-2-text-to-image`.

Minimal request (no `callBackUrl` required — polling works without it):

```json
{
  "model": "gpt-image-2-text-to-image",
  "input": {
    "prompt": "Create ONE separate 1:1 square social media carousel slide..."
  }
}
```

Observed generation time: ~2 minutes per slide (10-12 polls x 10s interval). Each slide generates independently. For a 4-slide carousel, generate and poll sequentially (not parallel) to avoid rate limits — total ~8-12 minutes.

Add `callBackUrl` only if you want asynchronous delivery; without it, polling `/api/v1/jobs/recordInfo` works identically.

For carousel publishing workflows, generate and send four **separate** slide images rather than an all-in-one contact sheet. Still QA every Mongolian/Cyrillic word before publishing (see Pitfall 11).

Use `POST /api/v1/jobs/createTask` with model `nano-banana-2`.

For this user, when creating branded carousel posters where the reference style/font/phone-frame/logo-placement matters, default to KIE GPT Image 2 with model `gpt-image-2-text-to-image` instead of Nano Banana + local font overlay. Generate each carousel slide as a separate image/task unless the user explicitly asks for a contact sheet. QA Mongolian/Cyrillic spelling, logo, and phone number before sending or posting.

For GPT Image 2 poster/carousel generation through KIE, use `model: "gpt-image-2-text-to-image"` on the same marketplace jobs endpoint; see `references/kie-gpt-image-2-notes.md`. GPT Image 2 is useful when the user wants the full poster—including rounded-bold typography, phone frames, logo cards, and wave/footer styling—to match a reference image more closely than local font overlay can. For carousel publishing workflows, generate and send four **separate** slide images rather than an all-in-one contact sheet. Still QA every Mongolian/Cyrillic word before publishing.

For Mongolian-language posters, prefer a two-stage workflow: generate a text-free image/background first, then render all Mongolian/Cyrillic copy locally with Pillow, SVG, or HTML/CSS. Image models frequently misspell non-English text, and deterministic overlay makes the final asset reviewable and editable. See `references/mongolian-poster-text-overlay.md`.

Minimal request pattern:

```bash
curl --location 'https://api.kie.ai/api/v1/jobs/createTask' \
  -H "Authorization: Bearer $KIE_API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{
    "model": "nano-banana-2",
    "callBackUrl": "https://your-domain.com/api/callback",
    "input": {
      "prompt": "Create a cinematic poster ..."
    }
  }'
```

Prompt checklist for posters:

- State exact format: poster, thumbnail, product ad, event flyer, Instagram square, vertical story, etc.
- Include subject, setting, mood, color palette, lighting, typography instructions, and composition.
- If text must appear in the image, quote it exactly and keep it short.
- Specify brand constraints: logo placement, colors, avoid clutter, premium/minimal/playful style.
- Add negative constraints: no misspelled text, no extra logos, no distorted hands/faces, no watermark.
- If the user requires Mongolian text, strongly prefer `NO TEXT / NO LETTERS` in the generation prompt and add the Mongolian copy as a deterministic overlay afterward.
- If humans appear for this user's Mongolian audience, explicitly request Mongolian-looking / Ulaanbaatar-context people and verify the result visually.

## Veo 3.1 Fast Video Workflow

Use KIE's Veo 3.1 generation API for text-to-video, image-to-video, or reference/material based generation. For people-led social ads, especially when the user cares about the actor/model, environment, and first-two-second hook, first generate a still concept frame for approval before spending Veo credits. The still should lock the spokesperson look, setting, lighting, brand colors, and emotional contrast; then write the Veo prompt from the approved still. For multi-part continuation videos, generate sequentially and save each task/seed/reference id; pass Generation 1 into Generation 2, and Generation 2 into Generation 3 to preserve the same person/location.

Docs describe three modes:

- `TEXT_2_VIDEO` — text prompt only.
- `FIRST_AND_LAST_FRAMES_2_VIDEO` — transition video using one or two image frames.
- `REFERENCE_2_VIDEO` — material/reference-image driven video; docs note this is Fast-model oriented and supports 16:9 and 9:16.

Generation request pattern:

```bash
curl --location 'https://api.kie.ai/api/v1/veo/generate' \
  -H "Authorization: Bearer $KIE_API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{
    "prompt": "A dynamic 8-second product reveal video ...",
    "model": "veo3_fast",
    "aspectRatio": "9:16",
    "callBackUrl": "https://your-domain.com/api/callback"
  }'
```

Parameter names can vary by KIE docs/model version. If a request fails validation, inspect the latest docs or API error and adjust body keys rather than assuming the model is unavailable.

Video prompt checklist:

- Duration target and platform: TikTok/Reels/YouTube Shorts/ad bumper.
- Camera movement: push-in, pan, orbit, handheld, drone, macro, dolly zoom.
- Visual sequence: beginning, middle, end.
- Subject action and environment.
- Brand/product placement.
- Aspect ratio: 9:16 for vertical social, 16:9 for YouTube/landscape.
- Audio expectation: generated video may include audio; if separate narration is needed, generate TTS and combine later with a video editor/ffmpeg.

## ElevenLabs TTS via KIE Workflow

Use `POST /api/v1/jobs/createTask` with an ElevenLabs model, for example:

- `elevenlabs/text-to-speech-turbo-2-5`
- `elevenlabs/text-to-speech-multilingual-v2`
- `elevenlabs/text-to-dialogue-v3`

Minimal request pattern:

```bash
curl --location 'https://api.kie.ai/api/v1/jobs/createTask' \
  -H "Authorization: Bearer $KIE_API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{
    "model": "elevenlabs/text-to-speech-turbo-2-5",
    "callBackUrl": "https://your-domain.com/api/callback",
    "input": {
      "text": "Unlock powerful API with KIE.AI..."
    }
  }'
```

TTS script checklist:

- Keep social ads concise: 10-30 seconds unless user asks longer.
- Write in the user's requested language; for this user, Mongolian is often preferred when the target audience is Mongolian.
- Include pronunciation hints only if the model supports them or if text spelling helps.
- Avoid huge paragraphs; split into short spoken beats.
- Generate captions/subtitles from the final script when packaging content.

## Polling and Download Pattern

For marketplace jobs, submit to `createTask`, extract the task/job id from the response, then poll `GET /api/v1/jobs/recordInfo` or the model-specific record endpoint until completion.

Nano Banana 2 / marketplace record responses may report `data.state: "success"` while the actual output URL is stored as a JSON-encoded string in `data.resultJson` (for example `{"resultUrls":["https://..."]}`). Do not stop just because a simple recursive URL regex finds nothing in the outer JSON; explicitly parse `resultJson` when present, then download the first `resultUrls` item. If the final poster needs reliable non-English typography, generate the visual with **no text** and overlay the exact localized text locally using a font that supports the language.

For Veo 3.1, docs describe status values on `successFlag`:

- `0` — generating.
- `1` — success.
- `2` — failed before completion.
- `3` — generation failed after task creation/upstream failure.

Observed Veo 3.1 Fast success records can put the final MP4 URL under `data.response.resultUrls[0]`, with audio and continuity metadata under `data.response.hasAudioList[0]` and `data.response.seeds[0]`. When a request used reference `imageUrls`, do not download the first URL found anywhere in the record because it may be the input PNG/reference image; prefer `data.response.resultUrls[0]` and verify the saved file is an MP4 (`ftyp`, `ffprobe`) before sending to the user. See `references/kie-veo31-fast-continuation-and-downloads.md` for the full pattern.

Polling pattern:

```bash
# Pseudocode; adapt id field names to response body.
TASK_ID='...'
for i in $(seq 1 60); do
  curl -sS 'https://api.kie.ai/api/v1/jobs/recordInfo?taskId='"$TASK_ID" \
    -H "Authorization: Bearer $KIE_API_KEY"
  sleep 10
done
```

If the API returns a KIE-hosted file URL that needs conversion, use:

```bash
curl --location 'https://api.kie.ai/api/v1/common/download-url' \
  -H "Authorization: Bearer $KIE_API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{"url":"https://...generated-file..."}'
```

Then immediately download the temporary URL to local storage.

**CRITICAL: download-url response shape.** The endpoint returns `{"code":200, "msg":"success", "data":"https://..."}` where `data` is a **string** (the signed temporary download URL), **not** an object. Incorrect parsing (e.g. `data.get("downloadUrl", "")` on `body["data"]`) will silently yield `None` or an AttributeError, and the direct KIE tempfile URL will return HTTP 403 when accessed without the signed query parameters.

**Correct Python parsing:**

```python
# download-url response: {"code":200, "msg":"success", "data":"https://signed-url..."}
resp = urllib.request.urlopen(req, context=ctx, timeout=60)
body = json.loads(resp.read().decode("utf-8"))
signed_url = body["data"]  # <-- "data" is a string (the download URL), not a dict
assert isinstance(signed_url, str) and signed_url.startswith("http")
```

**Correct recordInfo response parsing (for GPT Image 2 / marketplace models):**

The `data.resultJson` field is a **JSON-encoded string** containing `{"resultUrls":["https://..."]}`, not a dict. Parse it explicitly:

```python
record = json.loads(poll_response_body)
result_json_raw = record.get("data", {}).get("resultJson", "{}")
if isinstance(result_json_raw, str):
    result_data = json.loads(result_json_raw)  # string → dict
else:
    result_data = result_json_raw
kie_url = result_data.get("resultUrls", [])[0]  # the KIE tempfile URL
```

**Correct polling response parsing (createTask/recordInfo):**

For marketplace models (Nano Banana 2, GPT Image 2), the record response has:
- `data.state` — `"generating"` / `"success"` / `"failed"`
- `data.resultJson` — a **JSON-encoded string** containing `{"resultUrls": ["https://..."]}`, not a dict

```python
record = poll_result  # dict from json.loads
result_json_raw = record.get("data", {}).get("resultJson", "{}")
if isinstance(result_json_raw, str):
    result_data = json.loads(result_json_raw)
else:
    result_data = result_json_raw
result_urls = result_data.get("resultUrls", [])
kie_url = result_urls[0]  # the KIE tempfile URL
# Then convert via /api/v1/common/download-url as above
```

## Automated Cron Job Generation (no_agent: True)

When KIE.AI is used inside a `no_agent: true` cron job script (pure Python, no LLM), see the full reference at `references/kie-cron-auto-carousel-pattern.md`.

### Architecture Choice

Two cron job architectures exist for brand carousel autopost:

| Pattern | How | When |
|---|---|---|
| **LLM-driven** | Hermes agent generates images via `image_generate()` tool, then script sends to webhook | Need agent reasoning, flexible topic extraction, variable slide design |
| **Script-only (no_agent:true)** | Pure Python script calls KIE API directly for all 4 slides, polls, downloads, then sends to Make.com | Deterministic, no LLM tokens, simpler failure recovery, faster iteration |

Cron config for script-only:
```yaml
script: "brand_daily_carousel.py"   # bare filename in ~/.hermes/scripts/
no_agent: true
enabled_toolsets: ["terminal"]
```

### ⚠️ Critical: Brand Assets via Deterministic Overlay, Not Prompt

**Never trust GPT Image 2 prompts to reproduce actual brand logos, colors, or designed elements.** Even with detailed hex codes and descriptions, the model invents its own logo and picks random brand-adjacent colors.

**The correct approach is two-stage:**
1. **Stage 1 — Background image** generated via KIE (GPT Image 2 or Nano Banana 2) with `NO TEXT, NO LETTERS, NO LOGOS, NO WATERMARKS`
2. **Stage 2 — Pillow compositing** that overlays the actual brand logo PNG, exact brand color hex codes, fixed text elements (title, phone, slide numbers), and designed frames/ribbons/capsules

See `references/kie-cron-auto-carousel-pattern.md` sections 7-10 for the full dual-stage pattern, Pillow compositing code, and prompt template for background-only generation.

## Multi-Asset Content Pack Recipe

For a campaign request like "make content for this product":

1. Draft a concise creative brief:
   - Target audience.
   - Offer/CTA.
   - Tone.
   - Platform and aspect ratios.
   - Required language.
2. Write the poster prompt for Nano Banana 2.
3. Write the video prompt for Veo 3.1 Fast.
4. Write a 10-30 second voiceover script.
5. Generate poster/image first; use it as a visual reference for video if suitable.
6. Generate video.
7. Generate TTS.
8. Save all outputs under a dated project directory.
9. Provide the user a compact review package: file paths, scripts, prompts used, and recommended caption/hashtags.
10. If publishing is requested, switch to approval-first social automation: preview first, publish only after explicit approval.

## Reference Files

- `references/kie-api-notes.md` — endpoint notes and observed request/response shapes.
- `references/supernova-two-stage-carousel-overlay.md` — Supernova brand carousel two-stage pattern: text-free background via KIE + Pillow overlay with actual brand logo, exact color hexes, and fixed Mongolian text elements. Includes brand color table, background prompt template, Pillow CLI usage, and automation integration notes.
- `references/kie-veo-result-download-continuation.md` — Veo 3.1 Fast polling, result URL extraction, continuation IDs/seeds, and MP4 verification pitfalls.
- `references/kie-veo-continuation-spokesperson-ads.md` — Veo 3.1 Fast multi-generation continuation ads with same-character storytelling, task/seed handoff, audio QA, and Postly-style spokesperson examples.
- `references/kie-cron-auto-carousel-pattern.md` — `no_agent: true` cron script pattern for daily GPT Image 2 carousel generation with Make.com webhook, state file advancement, shell escaping pitfalls, and timing/cost estimates.
- `references/brand-carousel-prompt-authoring.md` — workflow for extracting brand identity, layout rules, slide structure, and content type labels from a user and saving as a reusable carousel image generation prompt document (for ChatGPT, KIE GPT Image 2, or other image generators). Covers style references, image placement rules per content type, and two delivery options (user self-designs vs automated generation).
- `references/testimonial-photo-two-stage-overlay.md` — two-stage overlay pattern for student/testimonial carousels: generate branded slide background via KIE GPT Image 2, then overlay actual person photo via Pillow with rounded corners. Includes concrete Batbaatar example and compositing code.
- `references/openai-vision-image-review.md` — OpenAI GPT-4o vision review workflow for carousel image QA. Covers review script usage, scoring rubric, JSON output parsing, and cron integration. Companion script at `scripts/review_image.py`.
- `scripts/generate_kie_carousel.py` — Generic Python template for generating N slides via KIE GPT Image 2, with correct download URL parsing, polling, and error handling. Copy and modify for each brand/carousel.
- `scripts/review_image.py` — OpenAI GPT-4o vision quality review for carousel images. Passes/fails automatically with structured JSON output. See `references/openai-vision-image-review.md`.

## Common Pitfalls

1. **API key in code.** Always use `KIE_API_KEY` env var. Store in `/opt/data/.env` as `KIE_API_KEY=...` for cron scripts to load, never write the literal key into scripts or prompts.

2. **Stale API docs.** KIE docs are Apidog-generated and endpoint schemas may evolve. If validation fails, use the error body to update parameter names.

3. **Infinite polling.** Set a bounded retry count (30 attempts × 10s = 5 min max). Report timeout as failure rather than hanging.

4. **Expiring download URLs.** Temporary KIE download URLs expire quickly. Save files to disk immediately once a final URL is available.

5. **Overstuffed image text.** Poster models struggle with long non-English copy. For Mongolian, generate text-free images (`NO TEXT, NO LETTERS, NO LOGOS, NO WATERMARKS`) with clean negative space, then overlay text locally with Pillow using a font that supports Cyrillic/Mongolian. See `references/mongolian-poster-text-overlay.md`.

6. **Hard typography panels.** When overlaying text on portrait images, prefer smooth full-canvas gradients and blurred backplates over hard rectangles. Hard edges across faces look like artifacts.

7. **Publishing without approval.** Content generation is not publication. For this user: approval-first workflow.

8. **Language mismatch.** For Mongolian audience content, default to Mongolian text unless the user specifies otherwise.

9. **Shell escaping non-ASCII prompts.** Never pass Cyrillic/CJK text through shell `-d '...'` — the shell mangles UTF-8 bytes. Use Python's `urllib.request` or a temp JSON file with `curl -d @file.json`.

10. **Cron script path restriction.** Script files must be relative filenames in `~/.hermes/scripts/`. Absolute paths are rejected with an error.

14. **GPT Image 2 Mongolian QA.** The model can misspell Mongolian text despite good visual style. Always QA slide text before publishing. If exact text fidelity matters more than visual style, use text-free image + local overlay.

15. **User-provided template compositing (not KIE-generated background).** When the user sends their own template image (JPEG/PNG) and says "use this as the background," do NOT send it to KIE for re-generation. Instead:
    - Use the user's image directly as the base canvas
    - Only overlay the brand's actual logo, person photo, and any missing text
    - Cover/remove any pre-existing old logo on the template by sampling nearby background color and drawing a filled rectangle before placing the new logo
    - Use smooth anti-aliased rounded corners for person photos (render at 4x resolution, then downscale with LANCZOS)
    - Use soft shadow (GaussianBlur) instead of sharp colored borders around photos — gold borders create jagged corner artifacts
    - Verify the template has no overlapping elements before sending to the user
    - This pattern was specifically corrected: the user had a ready template and I was wasting credits generating a new KIE version. The review script at `scripts/review_image.py` should catch overlapping logo issues.

12. **GPT Image 2 invents brand assets.** Prompt-only generation does not produce real brand logos or accurate brand colors. Always use deterministic Pillow overlay for brand elements (logo, colors, phone, frames).

13. **Missing Pillow or font dependencies for two-stage overlay.** Before starting a two-stage workflow that composites backgrounds + local text/logo, verify that (a) `Pillow` is importable in the target Python, (b) the font files referenced in the overlay script exist at their expected paths (e.g. `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf` for Cyrillic/Mongolian support), and (c) any brand logo asset is in PNG format with transparency (JPG opaque backgrounds look unnatural on composited slides). If these are missing, install/fix them before generating backgrounds — not after, or you'll waste KIE credits on backgrounds that can't be composited. For this user's server, create a venv at `/opt/data/.venv` and use `/opt/data/.venv/bin/python3` for Pillow operations.

14. **KIE queue "waiting" state**: GPT Image 2 tasks can get stuck in state `"waiting"` when the generation queue is congested. This is NOT a failure — the task is queued but hasn't started generating. Wait up to 90 polls (15 min). If it stays in `"waiting"` beyond that, submit a new task with a fresh task ID. Do NOT cancel early — tasks often auto-advance to `"generating"` after 10-30 polls.

17. **KIE generation speed varies wildly — retry on excessive timeouts.** Observed variation: a slide can take anywhere from ~90s (fast) to >600s (stuck in `"generating"`). If a task hasn't completed after 60 polls (10 min), it may be stuck. Instead of waiting indefinitely, submit a fresh task for that slide with a slightly simplified prompt (shorter body text, fewer visual constraints). The stuck task will either finish later (can be discarded) or fail — either way a fresh parallel task gives a recovery path. Do NOT assume a long-running task will fail; it may still complete. Let the retry run alongside the original.

18. **Python path mismatch in background/cron scripts.** The Hermes venv Python (`/opt/hermes/.venv/bin/python3`) has Pillow, openai, and other packages. The system Python (`/usr/bin/python3`) does not. When running compositing or review scripts via `terminal(background=true)` or cron `script:`, either:
    - Use explicit path: `/opt/hermes/.venv/bin/python3 /path/to/script.py`
    - Or set shebang to `#!/opt/hermes/.venv/bin/python3` in the script file
    - Or export `PATH="/opt/hermes/.venv/bin:$PATH"` before running
    - Failing to do this causes `ModuleNotFoundError: No module named 'PIL'` or `'openai'` at runtime

17. **SSL verification in KIE Python scripts.** On this server, `urllib.request.urlopen()` raises SSL certificate errors when connecting to `api.kie.ai`. Always pass `context=ssl._create_unverified_context()` (import `ssl` and create `ssl_ctx = ssl._create_unverified_context()` once at the top of the script). Without this, every API call fails with a certificate verification error.

18. **`pip install openai` required for review script.** The review script at `/opt/data/scripts/review_image.py` uses `from openai import OpenAI`. If the `openai` package is not installed, the script crashes. Verify with `python3 -c "from openai import OpenAI; print('OK')"` before relying on the review pipeline.

## Carousel Comparison Slide Design: Side-by-Side, Not Sequential

When creating comparison/before-after carousel content (WITH vs WITHOUT, Problem vs Solution), the user prefers a **single split-frame slide** showing both sides simultaneously — not two sequential slides. This was explicitly corrected when I proposed separate "WITHOUT" and "WITH" slides; the user wanted them merged into one slide for instant visual contrast.

**Layout pattern:**
- Split the 1:1 square into two vertical halves
- LEFT (WITHOUT / Problem): dark theme (deep teal/navy), stressed visuals, 4 roles with salary totals
- RIGHT (WITH Postly / Solution): turquoise/bright theme, AI agent icons, low price point
- Thin vertical divider line in center
- Brand logo top-right corner

**Why this works:** The user wants the cost/salary savings to register in one glance — scrolling from one slide to another dilutes the comparison.

## Brand Logo Placement in Two-Stage Carousels

**ALWAYS include the actual brand logo on branded carousel images.** The user corrected me for forgetting it. This is not optional.

**Placement:** Top-right corner by default — the user explicitly confirmed this position. Use a small logo (≈18% of slide width) with margin.

**Before compositing, verify:**
1. The logo file exists at the brand's `assets/logos/` path
2. It loads correctly with Pillow (check with `Image.open()` before the generation loop)
3. If JPG (no alpha channel), paste without mask: `overlay.paste(logo, (x, y))`. If PNG with alpha, use the mask: `overlay.paste(logo, (x, y), logo)`

**Font verification before compositing:** ALWAYS test that font files load with `ImageFont.truetype()` BEFORE submitting KIE background generation jobs. A missing or corrupt font file wastes KIE credits on backgrounds that can't be composited. Run this check:

```python
try:
    font = ImageFont.truetype(FONT_BOLD, 40)
    print("Font loaded ✓")
except Exception as e:
    print(f"Font error: {e}")
    # Fallback to DejaVu Sans Bold which is known to work
    FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
```

## API Key Accessibility

`KIE_API_KEY` is set in the shell environment but NOT available in the `execute_code` tool's Python environment. When making KIE API calls, use the `terminal` tool with `curl` or Python via `python3 -c` in a shell command — not `execute_code`. If you need to run a script, write it to a file and invoke it via `terminal`.

## Concept Approval Workflow: Test One Slide First

When the user proposes a new campaign concept (carousel/reel campaign), do NOT generate the full set upfront. Follow this pattern:

1. **Present 2-3 concept directions** as text/tables (the user picks one)
2. **Generate ONE sample slide** from the chosen concept
3. **Send for review** — the user may want layout changes, different text, or brand positioning fixes
4. **Only after approval** of the test slide, proceed to generate the remaining slides

This saves KIE credits and avoids rework. The user explicitly said "test one slide first, if I like it we continue."

## User Design Preferences (Battushig / Postly & Supernova Brands)

When generating carousel poster content for this user's Mongolian brands, apply these design defaults:

### All brands
- **Cleaner, lighter, simpler** — the user explicitly asked for a "lighter, simpler version" with less visual noise. Prefer light/cream/soft backgrounds over dark or busy gradients, minimal text per slide (short headline + 1-2 bullets max), generous whitespace, and clean modern typography over cluttered infographic style.
- Verified reference example: beige/cream tones (#F4EFEB range), high brightness (200+/255), subtle contrast, portrait 1:1.5 ratio.

### Postly-specific
- Brand colors: turquoise (#4CBFDD, #5ED4C0), deep teal (#063B4A), white, soft sky (#EAFBFF)
- Font: Nunito Bold (check `/opt/data/fonts/Nunito-Bold.ttf` loads; fallback to DejaVu Sans Bold if it doesn't)
- Comparison/cost content: prefer side-by-side single slides over sequential
- Always include Postly logo top-right on all branded images
- Content is approval-first: generate one slide, send preview via Telegram, wait for approval before continuing

### Supernova-specific
- Red/blue medical styling, thinner borders and softer shadows
- Logo card and phone capsule for brand recognition
- See `references/supernova-two-stage-carousel-overlay.md`

## GPT Image 2 Section-Based Prompt Pattern

For carousel slides where you need predictable layout zoning, use the section-based prompt pattern documented in `references/gpt-image-2-section-prompt-pattern.md`. The pattern breaks the slide into named zones (TOP/MIDDLE/BOTTOM) with specific content, hex colors, and styling per zone — yielding more reliable results than freeform single-block prompts for branded Mongolian carousels.
- Phone capsule, logo card, Supernova red/blue medical styling should remain for brand recognition, but use thinner borders and softer shadows.
- For future carousel templates, prefer simpler visual metaphors (one clear central element) over multi-element comparison layouts.

## Verification Checklist

- [ ] `KIE_API_KEY` was not written into any persistent file or final response.
- [ ] Credits were checked or the user accepted proceeding without a credit check.
- [ ] Request body used the intended model: Nano Banana 2, GPT Image 2, Veo 3.1 Fast, or ElevenLabs.
- [ ] Task id was captured.
- [ ] Polling reached success or a clear failure state was reported.
- [ ] Output URLs were converted/downloaded before temporary links expired.
- [ ] Local output paths and prompts/scripts were given to the user.
- [ ] Publishing, if any, waited for explicit approval.
- [ ] Shell escaping was avoided for non-ASCII prompts (used Python urllib or temp JSON file).
- [ ] Cron script is in `~/.hermes/scripts/`, not an absolute path.
- [ ] Environment dependencies verified for two-stage overlay: Pillow importable, fonts exist at expected paths, brand logo is PNG with alpha (or compositing path decided for JPG).