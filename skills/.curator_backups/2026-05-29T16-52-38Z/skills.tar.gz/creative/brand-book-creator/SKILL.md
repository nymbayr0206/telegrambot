---
name: brand-book-creator
description: "Create a one-page brand book from a logo image — analyzes brand colors, determines industry/vibe, suggests fonts, and generates 3 poster backgrounds (educational, industry leader, sales/promotion) composited into one large image via KIE GPT Image 2 + Pillow."
version: 1.0.0
author: Hermes Agent
tags: [branding, brand-book, kie-ai, gpt-image-2, poster-design, fashion, compositing]
---

# Brand Book Creator

## When to Use

Use this skill when the user uploads a **brand logo** (or describes one) and asks for a **brand book / brand guide** with visual backgrounds, color palette, and font suggestions. The skill produces **one large composite image** containing:

1. **Logo** (displayed at top)
2. **Color palette** (swatches with hex codes)
3. **Font suggestions** (headline + body font names)
4. **3 poster backgrounds** (generated via KIE GPT Image 2):
   - 🎓 **Educational poster background** — knowledge-sharing, seminar, workshop style
   - 🏆 **Industry leader poster background** — professional, authority, premium style
   - 🛒 **Sales & promotion background** — product sales, promotional, CTA style

The user reviews the one-pager and picks which background(s) to use further.

## Prerequisites

- `KIE_API_KEY` is set in environment (for KIE GPT Image 2 API)
- Pillow is installed (`pip install Pillow`)
- The user provides the brand logo (upload image) or describes the brand
- Fonts with Cyrillic/Mongolian support if user communicates in Mongolian (DejaVu Sans, Noto Sans, Nunito)

## Workflow

### Step 1: Get the Logo

Ask the user to upload their brand logo image. If they describe the brand without an image, ask clarifying questions:

- What industry?
- What feeling/vibe (professional, playful, luxury, modern, educational)?
- If user provides 2–3 brand colors, note them
- Any reference images or style preferences

### Step 2: Analyze the Logo with Vision

Use `vision_analyze()` on the logo image with this prompt:

```
Analyze this brand logo. Extract:
1. Dominant colors (top 3-4 hex codes)
2. What industry does this brand belong to?
3. What feeling/vibe does the logo convey? (luxury, modern, playful, professional, educational, etc.)
4. Logo style: minimal, detailed, abstract, mascot, typographic, emblem
5. Any visible typography style cues (serif, sans-serif, bold, thin, rounded, geometric)
```

**Vision fallback**: If `vision_analyze()` fails (model doesn't support it, API error), 
use the user's verbal description instead. Ask:
  - What are the brand's main colors? (get hex codes or color names)
  - What industry is this brand in?
  - What feeling/vibe should the brand convey?
  - Any specific font/style preferences?

Save the extracted:
- Primary brand colors (hex)
- Industry
- Vibe/mood keywords
- Logo style

### Step 3: Design the Brand Book Spec

Based on logo analysis, determine:

**Color palette** (if user didn't provide):
- 1–2 primary colors (from logo)
- 1–2 accent/secondary colors
- Neutral tones (dark for text, light for backgrounds)

**Font suggestions** (paired for the industry/vibe):

| Industry/Vibe | Headline Font | Body Font |
|---|---|---|
| Tech/Modern | Inter Bold, Montserrat Bold | Inter Regular, Open Sans |
| Luxury/High-end | Playfair Display, Cormorant Garamond | Lato, Proxima Nova |
| Education | Poppins Bold, Merriweather | Nunito, Source Sans |
| Health/Wellness | Lora, DM Serif Display | Nunito Sans, Rubik |
| Creative/Playful | Fredoka One, Baloo 2 | Quicksand, DM Sans |
| Professional/Corporate | Roboto Slab, IBM Plex Sans | Roboto, Work Sans |
| Finance/Authority | GT Walsheim, Montserrat | Inter, Source Sans Pro |

**Background concepts** (design briefs):

1. **🎓 Educational Background** — clean, bright, knowledge-sharing vibe. Books, lightbulbs, geometric shapes, soft gradients, whiteboard-clean aesthetic.
2. **🏆 Industry Leader Background** — premium, authoritative, professional. Dark or rich tones, subtle patterns, gold/foil accents, sleek lines, awards feel.
3. **🛒 Sales & Promotion Background** — energetic, CTA-focused, product-centered. Vibrant colors, price tags/discount elements, dynamic layout, arrow shapes, urgency feel.

## Approach A: One-Shot Generation (Faster, AI-designed layout)

Generate one single large image via KIE GPT Image 2 that contains everything — the entire brand book as one designed layout. The AI model creates the complete image in one generation call.

Endpoint: `POST https://api.kie.ai/api/v1/jobs/createTask`
Model: `gpt-image-2-text-to-image`
Aspect ratio: Suggest `4:3` portrait (tall layout fits more content)

**Prompt structure — describe the full layout as one unified design:**

```
Create ONE single large brand book / brand guide poster image. This is a complete brand identity reference sheet, not separate images. All content below must appear in this ONE image.

LAYOUT: A tall vertical poster divided into sections:
- TOP: Brand logo prominently displayed. Brand name below it.
- SECTION 2: Color palette — 3 to 4 color swatches shown as circles or rectangles with hex codes next to each.
- SECTION 3: Font suggestions — show "HEADLINE FONT: [FontName]" and "BODY FONT: [FontName]"
- SECTION 4 (LARGE, bottom area): Three poster background previews displayed side by side:
  1. 🎓 EDUCATIONAL POSTER BACKGROUND — [brief design description]
  2. 🏆 INDUSTRY LEADER POSTER BACKGROUND — [brief design description]  
  3. 🛒 SALES & PROMOTION BACKGROUND — [brief design description]

COLOR PALETTE:
- Primary: [HEX1], [HEX2]
- Accent: [HEX3], [HEX4]
- Background: Clean white or light neutral

STYLE:
- Industry: [industry]
- Vibe: [vibe keywords]
- Clean, professional brand guide aesthetic
- Modern, minimal layout
- High resolution
- NO text misspellings
- NO watermarks
```

**Pros**: 1 generation call (~3 min), simpler workflow.
**Cons**: AI may misspell text, layout may not match expectations exactly.

## Approach B: Separate Backgrounds + Pillow Composite (More Control, Deterministic)

Generate 3 text-free background images separately, then composite them with the logo, color swatches, and font labels deterministically using Pillow.

### Step 4a: Generate 3 Text-Free Backgrounds

Generate each background as a text-free image (NO TEXT, NO LETTERS, NO LOGOS) using KIE GPT Image 2. Generate sequentially (one at a time) to avoid rate limits.

See `references/bg-prompt-templates.md` for reusable prompts and full Python submission/polling code.

**KIE Queue Pitfall**: The API may return state `"waiting"` when the generation queue is congested. If the state stays `"waiting"` for more than 10 polls (100s), the task may eventually auto-advance to `"generating"`. Wait up to 90 polls (15 min). If it still hasn't progressed, submit a new task — the first one may be stuck in a dead queue.

### Step 4b: Composite with Pillow

Use `scripts/composite_brand_book.py` to merge the logo + 3 backgrounds + color swatches + font labels into one large image:

```bash
python3 scripts/composite_brand_book.py <logo.png> <bg_edu.jpg> <bg_leader.jpg> <bg_sales.jpg> output.jpg --title "Brand Name" --colors "#HEX1" "#HEX2" "#HEX3" "#HEX4"
```

**Pros**: Deterministic text/logo rendering, no misspellings, full control over layout.
**Cons**: 3 separate KIE calls (~7-10 min total), more code to maintain.

### Choosing an Approach

- **Use Approach A (one-shot)** when: the user wants a quick preview, text accuracy isn't critical, or the brand is English-only.
- **Use Approach B (separate + Pillow)** when: the user needs deterministic text/logo rendering, the brand uses Mongolian/Cyrillic text, or layout precision matters.

### Step 5: Deliver & Get Feedback

Send the image to the user via `MEDIA:/path/to/brand-book.jpg`. Ask:

- Do they like it?
- What adjustments (colors, fonts, background styles)?
- Do they want separate full-res versions of any background?

## Important Notes

- **KIE API key**: Never hardcode in files. Use env var `$KIE_API_KEY`.
- **Cyrillic/Mongolian text**: KIE GPT Image 2 may misspell non-English text. For Approach A (one-shot), minimize text in the prompt. For Approach B, use text-free backgrounds + deterministic Pillow overlay.
- **KIE Queue State**: The API returns `"waiting"` when congested, `"generating"` while processing, `"success"` when done. Never assume a `"waiting"` task is stuck — it may just be queued. Poll for up to 90 attempts (15 min) before retrying with a new task ID.
- **Download promptly**: KIE download URLs expire quickly; save to disk immediately after polling completes.
- **Font path**: DejaVu Sans at `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf` supports Cyrillic/Mongolian. Verify before compositing.

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Pillow not installed | `pip install Pillow` |
| KIE API returns error | Check `KIE_API_KEY` is set: `echo $KIE_API_KEY` |
| KIE queue stuck on "waiting" | Wait up to 15 min (90 polls × 10s). If still waiting, submit a new task |
| Text in composite is garbled | Use text-free backgrounds and overlay text with Pillow |
| Can't find font | `apt-get install fonts-dejavu-core` on Linux |
| Vision analysis not available | Fall back to verbal flow — ask user for colors, industry, vibe (see Step 2) |
| Background generation fails | Simplify prompt, remove complex descriptions, try again |

## Linked Files

- `scripts/composite_brand_book.py` — Pillow compositing script for Approach B. Usage:
  ```bash
  python3 scripts/composite_brand_book.py <logo.png> <bg_edu.jpg> <bg_leader.jpg> <bg_sales.jpg> output.jpg --title "Brand Name" --colors "#HEX1" "#HEX2" "#HEX3"
  ```
- `references/bg-prompt-templates.md` — reusable KIE GPT Image 2 prompts for all 3 background types + full Python submission/polling code.
